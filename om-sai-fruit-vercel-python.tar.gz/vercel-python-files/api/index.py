from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash
import json

app = Flask(__name__)
CORS(app)

# Database setup
def init_db():
    conn = sqlite3.connect('omsai_fruit.db')
    cursor = conn.cursor()
    
    # Products table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            category TEXT NOT NULL,
            unit TEXT DEFAULT '1 Kg',
            image TEXT,
            available INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Admin users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admin_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Insert admin user if not exists
    cursor.execute("SELECT COUNT(*) FROM admin_users WHERE email = ?", ("fmkpildo@minimax.com",))
    if cursor.fetchone()[0] == 0:
        hashed_password = generate_password_hash("yLTfFmi8mE")
        cursor.execute("INSERT INTO admin_users (email, password) VALUES (?, ?)", 
                      ("fmkpildo@minimax.com", hashed_password))
    
    # Insert sample products if not exists
    cursor.execute("SELECT COUNT(*) FROM products")
    if cursor.fetchone()[0] == 0:
        sample_products = [
            ("Apple", 120, "Fruits", "1 Kg", "https://via.placeholder.com/200x200/22C55E/FFFFFF?text=Apple", 1),
            ("Banana", 60, "Fruits", "1 Kg", "https://via.placeholder.com/200x200/FEF08A/000000?text=Banana", 1),
            ("Orange", 80, "Fruits", "1 Kg", "https://via.placeholder.com/200x200/F97316/FFFFFF?text=Orange", 1),
            ("Tomato", 40, "Vegetables", "1 Kg", "https://via.placeholder.com/200x200/EF4444/FFFFFF?text=Tomato", 1),
            ("Onion", 30, "Vegetables", "1 Kg", "https://via.placeholder.com/200x200/A855F7/FFFFFF?text=Onion", 1),
            ("Potato", 25, "Vegetables", "1 Kg", "https://via.placeholder.com/200x200/8B5CF6/FFFFFF?text=Potato", 1),
            ("Grapes", 150, "Fruits", "1 Kg", "https://via.placeholder.com/200x200/7C3AED/FFFFFF?text=Grapes", 1),
            ("Spinach", 20, "Vegetables", "1 Bundle", "https://via.placeholder.com/200x200/059669/FFFFFF?text=Spinach", 1),
            ("Carrot", 35, "Vegetables", "1 Kg", "https://via.placeholder.com/200x200/DC2626/FFFFFF?text=Carrot", 1),
            ("Mango", 200, "Fruits", "1 Kg", "https://via.placeholder.com/200x200/FB923C/FFFFFF?text=Mango", 1),
            ("Cucumber", 15, "Vegetables", "1 Kg", "https://via.placeholder.com/200x200/10B981/FFFFFF?text=Cucumber", 1),
            ("Pineapple", 180, "Fruits", "1 Piece", "https://via.placeholder.com/200x200/EAB308/FFFFFF?text=Pineapple", 1)
        ]
        cursor.executemany("INSERT INTO products (name, price, category, unit, image, available) VALUES (?, ?, ?, ?, ?, ?)", 
                          sample_products)
    
    conn.commit()
    conn.close()

# Initialize database
init_db()

# API Routes

@app.route('/api/products', methods=['GET'])
def get_products():
    try:
        conn = sqlite3.connect('omsai_fruit.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM products WHERE available = 1")
        products = cursor.fetchall()
        conn.close()
        
        products_list = []
        for product in products:
            products_list.append({
                'id': product[0],
                'name': product[1],
                'price': product[2],
                'category': product[3],
                'unit': product[4],
                'image': product[5],
                'available': bool(product[6])
            })
        
        return jsonify(products_list)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/products', methods=['POST'])
def add_product():
    try:
        data = request.json
        conn = sqlite3.connect('omsai_fruit.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO products (name, price, category, unit, image, available) VALUES (?, ?, ?, ?, ?, ?)",
                      (data['name'], data['price'], data['category'], data.get('unit', '1 Kg'), data.get('image', ''), 1))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Product added successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    try:
        data = request.json
        conn = sqlite3.connect('omsai_fruit.db')
        cursor = conn.cursor()
        cursor.execute("UPDATE products SET name = ?, price = ?, category = ?, unit = ?, image = ?, available = ? WHERE id = ?",
                      (data['name'], data['price'], data['category'], data['unit'], data.get('image', ''), data.get('available', 1), product_id))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Product updated successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    try:
        conn = sqlite3.connect('omsai_fruit.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Product deleted successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    try:
        data = request.json
        email = data.get('email')
        password = data.get('password')
        
        conn = sqlite3.connect('omsai_fruit.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, password FROM admin_users WHERE email = ?", (email,))
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user[1], password):
            return jsonify({'message': 'Login successful', 'user_id': user[0]})
        else:
            return jsonify({'error': 'Invalid credentials'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Static files
@app.route('/')
def home():
    return send_from_directory('static', 'index.html')

@app.route('/admin')
def admin():
    return send_from_directory('static', 'admin.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# Vercel requires this for the app to run
app.run(debug=False)