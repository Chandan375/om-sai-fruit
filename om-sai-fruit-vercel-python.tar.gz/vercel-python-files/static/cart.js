// Cart Management Module
class CartManager {
    constructor() {
        this.cart = this.loadCart();
        this.listeners = [];
    }

    loadCart() {
        const savedCart = localStorage.getItem('omsai-cart');
        if (savedCart) {
            try {
                return JSON.parse(savedCart);
            } catch (error) {
                console.error('Error loading cart:', error);
                return [];
            }
        }
        return [];
    }

    saveCart() {
        localStorage.setItem('omsai-cart', JSON.stringify(this.cart));
        this.notifyListeners();
    }

    addToCart(product) {
        const existingItem = this.cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push({ ...product, quantity: 1 });
        }
        this.saveCart();
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCart();
    }

    updateQuantity(productId, quantity) {
        if (quantity <= 0) {
            this.removeFromCart(productId);
            return;
        }
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            item.quantity = quantity;
            this.saveCart();
        }
    }

    clearCart() {
        this.cart = [];
        localStorage.removeItem('omsai-cart');
        this.notifyListeners();
    }

    getCart() {
        return this.cart;
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    getCartCount() {
        return this.cart.reduce((count, item) => count + item.quantity, 0);
    }

    subscribe(listener) {
        this.listeners.push(listener);
    }

    notifyListeners() {
        this.listeners.forEach(listener => listener(this.cart));
    }
}

// Create global cart instance
const cartManager = new CartManager();
