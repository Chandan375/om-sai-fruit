// Admin Panel JavaScript
const API_BASE_URL = '/api';

let products = [];
let currentUser = null;
let editingProduct = null;
let currentImageUrl = null;

// DOM Elements
const loginScreen = document.getElementById('loginScreen');
const adminDashboard = document.getElementById('adminDashboard');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const logoutBtn = document.getElementById('logoutBtn');
const addProductBtn = document.getElementById('addProductBtn');
const productModal = document.getElementById('productModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const cancelBtn = document.getElementById('cancelBtn');
const productForm = document.getElementById('productForm');
const loadingProducts = document.getElementById('loadingProducts');
const productsTableContainer = document.getElementById('productsTableContainer');
const productsTableBody = document.getElementById('productsTableBody');
const modalTitle = document.getElementById('modalTitle');
const productImage = document.getElementById('productImage');
const imageUploadArea = document.getElementById('imageUploadArea');
const imagePreview = document.getElementById('imagePreview');
const uploadPrompt = document.getElementById('uploadPrompt');
const previewImg = document.getElementById('previewImg');
const changeImageBtn = document.getElementById('changeImageBtn');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
});

// Check authentication
function checkAuth() {
    const savedUser = localStorage.getItem('omsai-admin-user');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            showDashboard();
        } catch (error) {
            console.error('Error loading user:', error);
            showLogin();
        }
    } else {
        showLogin();
    }
}

function showLogin() {
    loginScreen.classList.remove('hidden');
    adminDashboard.classList.add('hidden');
}

function showDashboard() {
    loginScreen.classList.add('hidden');
    adminDashboard.classList.remove('hidden');
    fetchProducts();
}

// Setup event listeners
function setupEventListeners() {
    loginForm.addEventListener('submit', handleLogin);
    logoutBtn.addEventListener('click', handleLogout);
    addProductBtn.addEventListener('click', () => openProductModal());
    closeModalBtn.addEventListener('click', closeProductModal);
    cancelBtn.addEventListener('click', closeProductModal);
    productForm.addEventListener('submit', handleSaveProduct);
    imageUploadArea.addEventListener('click', () => productImage.click());
    productImage.addEventListener('change', handleImageSelect);
    changeImageBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        productImage.click();
    });
}

// Login handler
async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    loginError.classList.add('hidden');
    
    try {
        const response = await fetch(`${API_BASE_URL}/admin/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            currentUser = data.user;
            localStorage.setItem('omsai-admin-user', JSON.stringify(currentUser));
            showDashboard();
        } else {
            loginError.textContent = data.message || 'Invalid credentials';
            loginError.classList.remove('hidden');
        }
    } catch (error) {
        console.error('Login error:', error);
        loginError.textContent = 'Failed to connect to server. Please check if the backend is running.';
        loginError.classList.remove('hidden');
    }
}

// Logout handler
function handleLogout() {
    currentUser = null;
    localStorage.removeItem('omsai-admin-user');
    showLogin();
}

// Fetch products
async function fetchProducts() {
    try {
        loadingProducts.classList.remove('hidden');
        productsTableContainer.classList.add('hidden');
        
        const response = await fetch(`${API_BASE_URL}/products?all=true`);
        if (!response.ok) throw new Error('Failed to fetch products');
        
        const data = await response.json();
        products = data.products || [];
        
        renderProductsTable();
    } catch (error) {
        console.error('Error fetching products:', error);
        loadingProducts.innerHTML = '<p style="color: var(--error);">Failed to load products</p>';
    }
}

// Render products table
function renderProductsTable() {
    loadingProducts.classList.add('hidden');
    productsTableContainer.classList.remove('hidden');
    
    if (products.length === 0) {
        productsTableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--neutral-500); padding: 2rem;">No products found</td></tr>';
        return;
    }
    
    productsTableBody.innerHTML = products.map(product => createProductRow(product)).join('');
    
    // Add event listeners
    products.forEach(product => {
        const editBtn = document.getElementById(`edit-${product.id}`);
        const deleteBtn = document.getElementById(`delete-${product.id}`);
        
        if (editBtn) {
            editBtn.addEventListener('click', () => openProductModal(product));
        }
        
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => handleDeleteProduct(product.id));
        }
    });
}

// Create product table row
function createProductRow(product) {
    const imageHTML = product.image_url 
        ? `<img src="${product.image_url}" alt="${product.name}">`
        : '';
    
    return `
        <tr>
            <td>
                <div class="product-thumb">${imageHTML}</div>
            </td>
            <td class="product-name-cell">${product.name}</td>
            <td class="product-category-cell">${product.category}</td>
            <td class="product-price-cell">Rs${product.price.toFixed(2)}</td>
            <td>${product.unit}</td>
            <td>
                <span class="availability-badge ${product.daily_availability ? 'available' : 'unavailable'}">
                    ${product.daily_availability ? 'Available' : 'Unavailable'}
                </span>
            </td>
            <td>
                <div class="table-actions">
                    <button class="action-btn" id="edit-${product.id}">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                    </button>
                    <button class="action-btn delete" id="delete-${product.id}">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </button>
                </div>
            </td>
        </tr>
    `;
}

// Open product modal
function openProductModal(product = null) {
    editingProduct = product;
    currentImageUrl = product ? product.image_url : null;
    
    if (product) {
        modalTitle.textContent = 'Edit Product';
        document.getElementById('productId').value = product.id;
        document.getElementById('productName').value = product.name;
        document.getElementById('productCategory').value = product.category;
        document.getElementById('productPrice').value = product.price;
        document.getElementById('productUnit').value = product.unit;
        document.getElementById('productAvailable').checked = product.daily_availability;
        
        if (product.image_url) {
            previewImg.src = product.image_url;
            imagePreview.classList.remove('hidden');
            uploadPrompt.classList.add('hidden');
        }
    } else {
        modalTitle.textContent = 'Add New Product';
        productForm.reset();
        imagePreview.classList.add('hidden');
        uploadPrompt.classList.remove('hidden');
    }
    
    productModal.classList.remove('hidden');
}

// Close product modal
function closeProductModal() {
    productModal.classList.add('hidden');
    productForm.reset();
    editingProduct = null;
    currentImageUrl = null;
    imagePreview.classList.add('hidden');
    uploadPrompt.classList.remove('hidden');
}

// Handle image selection
function handleImageSelect(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            previewImg.src = reader.result;
            imagePreview.classList.remove('hidden');
            uploadPrompt.classList.add('hidden');
        };
        reader.readAsDataURL(file);
    }
}

// Handle save product
async function handleSaveProduct(e) {
    e.preventDefault();
    
    const formData = new FormData();
    const productId = document.getElementById('productId').value;
    
    formData.append('name', document.getElementById('productName').value);
    formData.append('category', document.getElementById('productCategory').value);
    formData.append('price', document.getElementById('productPrice').value);
    formData.append('unit', document.getElementById('productUnit').value);
    formData.append('daily_availability', document.getElementById('productAvailable').checked);
    
    // Handle image upload
    const imageFile = productImage.files[0];
    if (imageFile) {
        formData.append('image', imageFile);
    } else if (currentImageUrl) {
        formData.append('existing_image_url', currentImageUrl);
    }
    
    try {
        const url = editingProduct 
            ? `${API_BASE_URL}/products/${productId}`
            : `${API_BASE_URL}/products`;
        
        const method = editingProduct ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            body: formData
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            closeProductModal();
            fetchProducts();
        } else {
            alert(data.message || 'Failed to save product');
        }
    } catch (error) {
        console.error('Error saving product:', error);
        alert('Failed to save product');
    }
}

// Handle delete product
async function handleDeleteProduct(productId) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/products/${productId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            fetchProducts();
        } else {
            alert(data.message || 'Failed to delete product');
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        alert('Failed to delete product');
    }
}
