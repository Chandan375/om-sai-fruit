// Main JavaScript for Customer Page
const API_BASE_URL = '/api';

let allProducts = [];
let activeCategory = 'fruits';

// DOM Elements
const productGrid = document.getElementById('productGrid');
const loadingState = document.getElementById('loadingState');
const categoryTabs = document.querySelectorAll('.category-tab');
const cartButton = document.getElementById('cartButton');
const cartBadge = document.getElementById('cartBadge');
const cartOverlay = document.getElementById('cartOverlay');
const cartDrawer = document.getElementById('cartDrawer');
const closeCartBtn = document.getElementById('closeCartBtn');
const cartBody = document.getElementById('cartBody');
const cartEmpty = document.getElementById('cartEmpty');
const cartItems = document.getElementById('cartItems');
const cartFooter = document.getElementById('cartFooter');
const cartCountBadge = document.getElementById('cartCountBadge');
const subtotalAmount = document.getElementById('subtotalAmount');
const deliveryArea = document.getElementById('deliveryArea');
const deliveryCharge = document.getElementById('deliveryCharge');
const totalAmount = document.getElementById('totalAmount');
const customerName = document.getElementById('customerName');
const customerPhone = document.getElementById('customerPhone');
const customerAddress = document.getElementById('customerAddress');
const whatsappOrderBtn = document.getElementById('whatsappOrderBtn');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    fetchProducts();
    setupEventListeners();
    updateCartUI();
    
    // Subscribe to cart changes
    cartManager.subscribe(() => {
        updateCartUI();
        updateCartDrawer();
    });
});

// Fetch products from API
async function fetchProducts() {
    try {
        loadingState.classList.remove('hidden');
        productGrid.classList.add('hidden');
        
        const response = await fetch(`${API_BASE_URL}/products`);
        if (!response.ok) throw new Error('Failed to fetch products');
        
        const data = await response.json();
        allProducts = data.products || [];
        
        renderProducts();
    } catch (error) {
        console.error('Error fetching products:', error);
        loadingState.innerHTML = '<p style="color: var(--error);">Failed to load products. Please check if the backend server is running.</p>';
    }
}

// Render products based on active category
function renderProducts() {
    const filteredProducts = allProducts.filter(p => 
        p.category === activeCategory && p.daily_availability
    );
    
    loadingState.classList.add('hidden');
    productGrid.classList.remove('hidden');
    
    if (filteredProducts.length === 0) {
        productGrid.innerHTML = '<p style="text-align: center; color: var(--neutral-500); grid-column: 1/-1;">No products available in this category.</p>';
        return;
    }
    
    productGrid.innerHTML = filteredProducts.map(product => createProductCard(product)).join('');
    
    // Add event listeners to product cards
    document.querySelectorAll('[data-product-id]').forEach(card => {
        const productId = card.dataset.productId;
        const product = allProducts.find(p => p.id === productId);
        
        const addToCartBtn = card.querySelector('.add-to-cart-btn');
        const quantityControl = card.querySelector('.quantity-control');
        const minusBtn = card.querySelector('.quantity-minus');
        const plusBtn = card.querySelector('.quantity-plus');
        
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', () => {
                cartManager.addToCart(product);
                renderProducts(); // Re-render to show quantity controls
            });
        }
        
        if (minusBtn) {
            minusBtn.addEventListener('click', () => {
                const cartItem = cartManager.getCart().find(item => item.id === productId);
                if (cartItem) {
                    cartManager.updateQuantity(productId, cartItem.quantity - 1);
                    renderProducts();
                }
            });
        }
        
        if (plusBtn) {
            plusBtn.addEventListener('click', () => {
                const cartItem = cartManager.getCart().find(item => item.id === productId);
                if (cartItem) {
                    cartManager.updateQuantity(productId, cartItem.quantity + 1);
                    renderProducts();
                }
            });
        }
    });
}

// Create product card HTML
function createProductCard(product) {
    const cartItem = cartManager.getCart().find(item => item.id === product.id);
    const quantity = cartItem ? cartItem.quantity : 0;
    
    const imageHTML = product.image_url 
        ? `<img src="${product.image_url}" alt="${product.name}" loading="lazy">`
        : `<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--neutral-400);">
            <path d="M12 2 L2 7 L12 12 L22 7 Z"></path>
            <path d="M2 17 L12 22 L22 17"></path>
            <path d="M2 12 L12 17 L22 12"></path>
           </svg>`;
    
    const actionHTML = quantity === 0 
        ? `<button class="btn btn-primary btn-full add-to-cart-btn">Add to Cart</button>`
        : `<div class="quantity-control">
                <button class="quantity-btn quantity-minus">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                </button>
                <span class="quantity-value">${quantity}</span>
                <button class="quantity-btn plus quantity-plus">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                </button>
           </div>`;
    
    return `
        <div class="product-card" data-product-id="${product.id}">
            <div class="product-image">${imageHTML}</div>
            <h3 class="product-name">${product.name}</h3>
            <p class="product-price">
                Rs${product.price.toFixed(2)}
                <span class="product-unit">/${product.unit}</span>
            </p>
            ${actionHTML}
        </div>
    `;
}

// Setup event listeners
function setupEventListeners() {
    // Category tabs
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            categoryTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            activeCategory = tab.dataset.category;
            renderProducts();
        });
    });
    
    // Cart drawer
    cartButton.addEventListener('click', openCart);
    cartOverlay.addEventListener('click', closeCart);
    closeCartBtn.addEventListener('click', closeCart);
    
    // Delivery area change
    deliveryArea.addEventListener('change', updateCartSummary);
    
    // WhatsApp order
    whatsappOrderBtn.addEventListener('click', handleWhatsAppOrder);
}

// Cart UI functions
function openCart() {
    cartOverlay.classList.add('active');
    cartDrawer.classList.add('active');
    updateCartDrawer();
}

function closeCart() {
    cartOverlay.classList.remove('active');
    cartDrawer.classList.remove('active');
}

function updateCartUI() {
    const count = cartManager.getCartCount();
    
    if (count > 0) {
        cartBadge.textContent = count;
        cartBadge.classList.remove('hidden');
    } else {
        cartBadge.classList.add('hidden');
    }
}

function updateCartDrawer() {
    const cart = cartManager.getCart();
    const count = cartManager.getCartCount();
    
    if (count > 0) {
        cartCountBadge.textContent = count;
        cartCountBadge.classList.remove('hidden');
        cartEmpty.classList.add('hidden');
        cartFooter.classList.remove('hidden');
        
        cartItems.innerHTML = cart.map(item => createCartItem(item)).join('');
        
        // Add event listeners to cart items
        cart.forEach(item => {
            const minusBtn = document.getElementById(`cart-minus-${item.id}`);
            const plusBtn = document.getElementById(`cart-plus-${item.id}`);
            const removeBtn = document.getElementById(`cart-remove-${item.id}`);
            
            if (minusBtn) {
                minusBtn.addEventListener('click', () => {
                    cartManager.updateQuantity(item.id, item.quantity - 1);
                });
            }
            
            if (plusBtn) {
                plusBtn.addEventListener('click', () => {
                    cartManager.updateQuantity(item.id, item.quantity + 1);
                });
            }
            
            if (removeBtn) {
                removeBtn.addEventListener('click', () => {
                    cartManager.removeFromCart(item.id);
                });
            }
        });
        
        updateCartSummary();
    } else {
        cartCountBadge.classList.add('hidden');
        cartEmpty.classList.remove('hidden');
        cartFooter.classList.add('hidden');
        cartItems.innerHTML = '';
    }
}

function createCartItem(item) {
    return `
        <div class="cart-item">
            <div class="cart-item-header">
                <div class="cart-item-info">
                    <h3>${item.name}</h3>
                    <p>Rs${item.price.toFixed(2)}/${item.unit}</p>
                </div>
                <button class="icon-btn danger" id="cart-remove-${item.id}">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                    </svg>
                </button>
            </div>
            <div class="cart-item-footer">
                <div class="quantity-control" style="padding: 0.25rem; background: white; border: 1px solid var(--neutral-200);">
                    <button class="quantity-btn" id="cart-minus-${item.id}" style="width: 32px; height: 32px;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                        </svg>
                    </button>
                    <span class="quantity-value" style="font-size: 1rem;">${item.quantity}</span>
                    <button class="quantity-btn" id="cart-plus-${item.id}" style="width: 32px; height: 32px; background: transparent; color: var(--neutral-900); border: none;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="5" x2="12" y2="19"></line>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                        </svg>
                    </button>
                </div>
                <p class="cart-item-price">Rs${(item.price * item.quantity).toFixed(2)}</p>
            </div>
        </div>
    `;
}

function updateCartSummary() {
    const subtotal = cartManager.getCartTotal();
    const deliveryCharges = {
        'thakur-complex': 20,
        'thakur-village': 30,
        'other': 50
    };
    const delivery = deliveryCharges[deliveryArea.value];
    const total = subtotal + delivery;
    
    subtotalAmount.textContent = `Rs${subtotal.toFixed(2)}`;
    deliveryCharge.textContent = `Rs${delivery}`;
    totalAmount.textContent = `Rs${total.toFixed(2)}`;
}

function handleWhatsAppOrder() {
    const name = customerName.value.trim();
    const phone = customerPhone.value.trim();
    const address = customerAddress.value.trim();
    
    if (!name || !phone || !address) {
        alert('Please fill in all customer details');
        return;
    }
    
    const cart = cartManager.getCart();
    const subtotal = cartManager.getCartTotal();
    const areaNames = {
        'thakur-complex': 'Thakur Complex',
        'thakur-village': 'Thakur Village',
        'other': 'Other Mumbai Areas'
    };
    const deliveryCharges = {
        'thakur-complex': 20,
        'thakur-village': 30,
        'other': 50
    };
    const delivery = deliveryCharges[deliveryArea.value];
    const total = subtotal + delivery;
    
    let message = 'Om Sai Fruit - Order Details\n\n';
    message += 'Products:\n';
    cart.forEach((item, index) => {
        message += `${index + 1}. ${item.name} (${item.unit}) x${item.quantity} = Rs${(item.price * item.quantity).toFixed(2)}\n`;
    });
    message += `\nSubtotal: Rs${subtotal.toFixed(2)}\n`;
    message += `Delivery Area: ${areaNames[deliveryArea.value]}\n`;
    message += `Delivery Charge: Rs${delivery}\n`;
    message += `Total Amount: Rs${total.toFixed(2)}\n\n`;
    message += `Customer Name: ${name}\n`;
    message += `Phone: ${phone}\n`;
    message += `Address: ${address}\n\n`;
    message += 'Please confirm the order.';
    
    const whatsappNumber = '9892779843';
    window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank');
    
    // Clear cart and form
    cartManager.clearCart();
    customerName.value = '';
    customerPhone.value = '';
    customerAddress.value = '';
    closeCart();
    renderProducts(); // Refresh products to remove quantity controls
}
