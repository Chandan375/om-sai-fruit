#!/usr/bin/env python3
"""
End-to-end testing script for Om Sai Fruit Application
Tests all features: API, Customer Page, Admin Panel
"""

import requests
import json
import time
import sys

BASE_URL = 'http://localhost:5000'
API_URL = f'{BASE_URL}/api'

def test_health():
    """Test health endpoint"""
    print("\n=== Testing Health Endpoint ===")
    try:
        response = requests.get(f'{API_URL}/health', timeout=5)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.json()}")
        assert response.status_code == 200
        assert response.json().get('status') == 'healthy'
        print("✓ Health check passed")
        return True
    except Exception as e:
        print(f"✗ Health check failed: {e}")
        return False

def test_get_products():
    """Test getting products"""
    print("\n=== Testing Get Products ===")
    try:
        response = requests.get(f'{API_URL}/products', timeout=5)
        print(f"Status: {response.status_code}")
        data = response.json()
        print(f"Products found: {len(data.get('products', []))}")
        
        if len(data.get('products', [])) > 0:
            print(f"Sample product: {data['products'][0]['name']}")
        
        assert response.status_code == 200
        assert data.get('success') == True
        print("✓ Get products passed")
        return True
    except Exception as e:
        print(f"✗ Get products failed: {e}")
        return False

def test_admin_login():
    """Test admin login"""
    print("\n=== Testing Admin Login ===")
    try:
        login_data = {
            'email': 'fmkpildo@minimax.com',
            'password': 'yLTfFmi8mE'
        }
        response = requests.post(f'{API_URL}/admin/login', json=login_data, timeout=5)
        print(f"Status: {response.status_code}")
        data = response.json()
        print(f"Response: {data}")
        
        assert response.status_code == 200
        assert data.get('success') == True
        assert data.get('user') is not None
        print("✓ Admin login passed")
        return True
    except Exception as e:
        print(f"✗ Admin login failed: {e}")
        return False

def test_admin_login_invalid():
    """Test admin login with invalid credentials"""
    print("\n=== Testing Invalid Admin Login ===")
    try:
        login_data = {
            'email': 'wrong@email.com',
            'password': 'wrongpassword'
        }
        response = requests.post(f'{API_URL}/admin/login', json=login_data, timeout=5)
        print(f"Status: {response.status_code}")
        data = response.json()
        
        assert response.status_code == 401
        assert data.get('success') == False
        print("✓ Invalid login rejected correctly")
        return True
    except Exception as e:
        print(f"✗ Invalid login test failed: {e}")
        return False

def test_create_product():
    """Test creating a product"""
    print("\n=== Testing Create Product ===")
    try:
        product_data = {
            'name': 'Test Fruit',
            'category': 'fruits',
            'price': '99.99',
            'unit': '1 Kg',
            'daily_availability': 'true'
        }
        response = requests.post(f'{API_URL}/products', data=product_data, timeout=5)
        print(f"Status: {response.status_code}")
        data = response.json()
        print(f"Response: {data}")
        
        assert response.status_code == 200
        assert data.get('success') == True
        print("✓ Create product passed")
        return data.get('product_id')
    except Exception as e:
        print(f"✗ Create product failed: {e}")
        return None

def test_update_product(product_id):
    """Test updating a product"""
    print("\n=== Testing Update Product ===")
    try:
        update_data = {
            'name': 'Updated Test Fruit',
            'price': '149.99'
        }
        response = requests.put(f'{API_URL}/products/{product_id}', data=update_data, timeout=5)
        print(f"Status: {response.status_code}")
        data = response.json()
        print(f"Response: {data}")
        
        assert response.status_code == 200
        assert data.get('success') == True
        print("✓ Update product passed")
        return True
    except Exception as e:
        print(f"✗ Update product failed: {e}")
        return False

def test_delete_product(product_id):
    """Test deleting a product"""
    print("\n=== Testing Delete Product ===")
    try:
        response = requests.delete(f'{API_URL}/products/{product_id}', timeout=5)
        print(f"Status: {response.status_code}")
        data = response.json()
        print(f"Response: {data}")
        
        assert response.status_code == 200
        assert data.get('success') == True
        print("✓ Delete product passed")
        return True
    except Exception as e:
        print(f"✗ Delete product failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("Om Sai Fruit - End-to-End Testing")
    print("=" * 60)
    print(f"Testing API at: {API_URL}")
    print("=" * 60)
    
    # Check if server is running
    print("\nChecking if backend server is running...")
    try:
        requests.get(BASE_URL, timeout=2)
    except:
        print("\n✗ BACKEND SERVER NOT RUNNING!")
        print("\nPlease start the backend server first:")
        print("  cd /workspace/om-sai-fruit-html")
        print("  python3 app.py")
        print("\nThen run this test script again.")
        sys.exit(1)
    
    results = []
    
    # Run tests
    results.append(("Health Check", test_health()))
    results.append(("Get Products", test_get_products()))
    results.append(("Admin Login (Valid)", test_admin_login()))
    results.append(("Admin Login (Invalid)", test_admin_login_invalid()))
    
    # CRUD operations
    product_id = test_create_product()
    if product_id:
        results.append(("Create Product", True))
        results.append(("Update Product", test_update_product(product_id)))
        results.append(("Delete Product", test_delete_product(product_id)))
    else:
        results.append(("Create Product", False))
        results.append(("Update Product", False))
        results.append(("Delete Product", False))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✓ PASSED" if result else "✗ FAILED"
        print(f"{test_name:.<40} {status}")
    
    print("=" * 60)
    print(f"Total: {passed}/{total} tests passed")
    print("=" * 60)
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED! The application is working correctly.")
        return 0
    else:
        print(f"\n⚠️  {total - passed} tests failed. Please check the errors above.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
